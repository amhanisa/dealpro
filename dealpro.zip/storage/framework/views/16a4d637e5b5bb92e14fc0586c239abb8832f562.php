

<?php $__env->startSection('content'); ?>
<section class="py-32 bg-gray-900">
    <div class="container mx-auto">
        <h1 class="font-bold text-8xl text-yellow-600">DCLTH</h1>
        <p>With DealPro’s DLCTH, you can improve your fashion experience through customization. Use your personal photo
            or design and embrace the new level of creativity. We can also help you boost your community branding
            through stylish and comfortable apparel. Let’s be an inspiration for others with DCLTH!</p>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Azka Muhammad\Documents\Code\dealpro\resources\views/frontend/dclth.blade.php ENDPATH**/ ?>