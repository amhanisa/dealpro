<?php $__env->startSection('content'); ?>
<section class="hero h-screen w-full overflow-hidden">
    <div class="w-full h-screen relative overflow-hidden">
        <div id="yt-hero" class="absolute yt-bg"></div>
    </div>
    <div class="absolute w-full h-screen top-0 z-10 hero-cover">
        <img src="<?php echo e(asset('img/test.jpg')); ?>" alt="Test" class="object-cover w-full h-screen">
    </div>
    <div class="absolute h-screen w-full z-10 top-0 bg-black bg-opacity-50">
        <div class="absolute bottom-0 w-full">
            <div class="block container mx-auto px-5 pb-16">
                <span class="font-bold text-4xl md:text-8xl text-white">
                    best of the best. be the best. wildebest
                </span>
            </div>
        </div>
    </div>
</section>

<section class="py-32 overflow-x-hidden">
    <div class="container mx-auto">
        <div class="swiper-container swiper-service ">
            <div class="swiper-wrapper">
                <div class="swiper-slide ">
                    <div class="transform scale-100 hover:scale-105 transition duration-150 ease-in-out">
                        <img src="<?php echo e(asset('img/service/service.png')); ?>" alt="DealPro Event" class="mb-5">
                        <h2 class="font-bold text-center text-xl">DealPro Event</h2>
                        <p class="text-center">Our professional & creative event organizer will grant your wishful
                            moment to a spectacular
                            experience</p>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="transform scale-100 hover:scale-105 transition duration-150 ease-in-out">
                        <img src="<?php echo e(asset('img/service/service.png')); ?>" alt="DealPro Event" class="mb-5">
                        <h2 class="font-bold text-center text-xl">Deal Production</h2>
                        <p class="text-center">National acclaimed event production supplier with high skilled staff
                            to
                            construct your event installation</p>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="transform scale-100 hover:scale-105 transition duration-150 ease-in-out">
                        <img src="<?php echo e(asset('img/service/service.png')); ?>" alt="DealPro Event" class="mb-5">
                        <h2 class="font-bold text-center text-xl">DealPrint Indonesia</h2>
                        <p class="text-center">From outdoor to indoor printing, our print, promotion & packaging
                            experts
                            are ready to turn your project into a thing of beauty
                        </p>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="transform scale-100 hover:scale-105 transition duration-150 ease-in-out">
                        <img src="<?php echo e(asset('img/service/service.png')); ?>" alt="DealPro Event" class="mb-5">
                        <h2 class="font-bold text-center text-xl">DCLTH</h2>
                        <p class="text-center">Boost your company branding through the unique experience of fashion
                            customization
                        </p>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="transform scale-100 hover:scale-105 transition duration-150 ease-in-out">
                        <img src="<?php echo e(asset('img/service/service.png')); ?>" alt="DealPro Event" class="mb-5">
                        <h2 class="font-bold text-center text-xl">Deal Medical</h2>
                        <p class="text-center">Performance scrubs for nurses and medical staff that feel great and
                            look
                            outstanding to maintain professional appearances
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="hero h-screen overflow-x-hidden">
    <div class="swiper-container swiper-number">
        <div class="swiper-wrapper">
            <div class="swiper-slide">
                <div class="absolute w-full h-screen bg-black bg-opacity-80">
                </div>
                <img src="<?php echo e(asset('img/test.jpg')); ?>" alt="Test" class="object-cover h-screen">
                <div class="absolute w-full bottom-0 pb-16 z-10 px-5">
                    <div class="block container mx-auto text-white">
                        <p class="font-bold text-2xl md:text-4xl">We have worked for more than</p>
                        <p class="font-bold text-7xl md:text-9xl" data-aos="fade-left">
                            Over <br>
                            1000 <br>
                            Events
                        </p>
                    </div>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="absolute w-full h-screen bg-black bg-opacity-80">
                </div>
                <img src="<?php echo e(asset('img/test.jpg')); ?>" alt="Test" class="object-cover h-screen">
                <div class="absolute w-full bottom-0 pb-16 z-10">
                    <div class="block container mx-auto text-white px-5">
                        <p class="font-bold text-2xl md:text-4xl">We help</p>
                        <p class="font-bold  text-7xl md:text-9xl">
                            12+ <br>
                            clients in a year
                        </p>
                    </div>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="absolute w-full h-screen bg-black bg-opacity-80">
                </div>
                <img src="<?php echo e(asset('img/test.jpg')); ?>" alt="Test" class="object-cover h-screen">
                <div class="absolute w-full bottom-0 pb-16 z-10 px-5">
                    <div class="block container mx-auto text-white">
                        <p class="font-bold text-7xl md:text-8xl ">
                            50K <br>
                            visitor in event
                        </p>
                    </div>
                </div>
            </div>


        </div>
        <div class="swiper-pagination"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-button-next"></div>
    </div>

</section>

<section class="py-32 overflow-x-hidden">
    <div class="container mx-auto px-5" data-aos="fade-left">
        <p>After 13 years, DealPro Indonesia believes that every moment matters. Our ideas to combine innovation,
            excitement, & creativity collide with extraordinary dreams will create extraordinary experience!</p>
    </div>
    <div id="player"></div>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Azka Muhammad\Documents\Code\dealpro\resources\views/welcome.blade.php ENDPATH**/ ?>