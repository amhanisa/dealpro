

<?php $__env->startSection('content'); ?>

<section class="py-32 bg-gray-900 text-gray-300">
    <div class="container mx-auto px-5">
        <div class="flex">
            <div>
                <h1>Client</h1>
                <p>Honda Main Dealer Bandung</p>
            </div>
            <div>
                <h1>Project</h1>
                <p>Honda Main Dealer Bandung</p>
            </div>
        </div>
        <p>Kita buka lowongan buat kamu gabung ke dalam keluarga kami.</p>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Azka Muhammad\Documents\Code\dealpro\resources\views/frontend/work/work.blade.php ENDPATH**/ ?>