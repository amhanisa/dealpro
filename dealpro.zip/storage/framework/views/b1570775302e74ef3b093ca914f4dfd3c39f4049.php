

<?php $__env->startSection('content'); ?>
<section class="py-32 bg-gray-900">
    <div class="container mx-auto">
        <h1 class="font-bold text-8xl text-yellow-600">Medical</h1>
        <p>We encourage our medical workers to confidently help others with style without degrading their performance
            feature. Deal Medical provides hospital scrubs with sophisticated material to support the community of
            health workers. Our medical scrubs feel great and look outstanding to maintain professional appearances.</p>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Azka Muhammad\Documents\Code\dealpro\resources\views/frontend/medical.blade.php ENDPATH**/ ?>